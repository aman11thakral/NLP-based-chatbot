import shutil

shutil.make_archive("backup", 'zip', r"C:\Users\admin\Desktop\IntelligentChatAssistant")